package com.AOP_basic;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Component
@Aspect
@EnableAspectJAutoProxy
public class Human {

	@Before("execution(public void study())")
	public void greet1() {
		System.out.println("good ");
	}
	
	@Before("execution(public void study())")
	public void greet() {
		
		System.out.println("good morning");
		System.err.println("zfsd");
	}
	
	
}
