package com.AOP_basic;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration   //make file as config file
@ComponentScan(basePackages = "com.AOP_basic")
public class AppConfig {

}
