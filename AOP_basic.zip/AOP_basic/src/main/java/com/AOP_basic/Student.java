package com.AOP_basic;

import org.springframework.stereotype.Component;

@Component  //creates bean 
public class Student {

	public void study() {
		System.out.println("study right now");
	}
}
