package com.AOP_basic;
import com.AOP_basic.*;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        AbstractApplicationContext con = new AnnotationConfigApplicationContext(AppConfig.class);
        Student st = con.getBean("student", Student.class);
        
        st.study();
       
    }
}
