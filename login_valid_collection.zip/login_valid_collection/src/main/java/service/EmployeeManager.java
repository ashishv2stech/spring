package service;

import java.util.ArrayList;
import java.util.List;
import pojo.*;
public class EmployeeManager 
{
	private static List<EmployeeCollection> employeeList;

	public EmployeeManager(){
		 employeeList = new ArrayList<EmployeeCollection>();
		 employeeList.add(new EmployeeCollection("1", "Mike", "Smith"));
		 employeeList.add(new EmployeeCollection("2", "John", "Taylor"));
		 employeeList.add(new EmployeeCollection("3", "Dave", "Wilson"));	 
	}

	public List<EmployeeCollection> getEmployeeList(){
		return employeeList;
	}

}