package pojo;

public class Student {

	String name;
	String address;
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Student(String name) {
		this.name=name;
	}
	
	public Student() {  // just 
		
	}
	
	public String showName() {
		 return "my name is : "+ name;
	}
	
	public String showAdd() {
		return "address is "+ address;
	}
}
